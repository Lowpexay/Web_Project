# Exercício para treinar o HTML e CSS :)
![image](https://user-images.githubusercontent.com/108759445/235384686-6f15acc8-8f48-4c83-9852-37229f976343.png)
